
@include('Admin.header')

@yield('main_content')





<!-- Footer -->
@include('Admin.footer')


